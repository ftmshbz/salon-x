"use strict";

const DB_NAME = "salon-x-portfolio";
const DB_VERSION = 1;
const STORE_NAME = "works";
const BOOKINGS_KEY = "salon-x-bookings";
const THEME_KEY = "salon-x-theme";

const elements = {
  root: document.documentElement,
  body: document.body,
  header: document.getElementById("siteHeader"),
  portfolioGrid: document.getElementById("portfolioGrid"),
  portfolioEmpty: document.getElementById("portfolioEmpty"),
  portfolioCount: document.getElementById("portfolioCount"),
  portfolioSearch: document.getElementById("portfolioSearch"),
  portfolioShape: document.getElementById("portfolioShape"),
  appointmentList: document.getElementById("appointmentList"),
  appointmentEmpty: document.getElementById("appointmentEmpty"),
  bookingForm: document.getElementById("bookingForm"),
  bookingSuccess: document.getElementById("bookingSuccess"),
  bookingSuccessText: document.getElementById("bookingSuccessText"),
  bookingName: document.getElementById("bookingName"),
  bookingPhone: document.getElementById("bookingPhone"),
  bookingService: document.getElementById("bookingService"),
  bookingColor: document.getElementById("bookingColor"),
  bookingBrand: document.getElementById("bookingBrand"),
  bookingDate: document.getElementById("bookingDate"),
  bookingTime: document.getElementById("bookingTime"),
  bookingNote: document.getElementById("bookingNote"),
  bookingImageInput: document.getElementById("bookingImageInput"),
  bookingReferenceZone: document.getElementById("bookingReferenceZone"),
  bookingReferencePlaceholder: document.getElementById("bookingReferencePlaceholder"),
  bookingReferencePreview: document.getElementById("bookingReferencePreview"),
  bookingReferenceImage: document.getElementById("bookingReferenceImage"),
  bookingImageError: document.getElementById("bookingImageError"),
  uploadDialog: document.getElementById("uploadDialog"),
  detailDialog: document.getElementById("detailDialog"),
  detailPanel: document.getElementById("detailPanel"),
  uploadForm: document.getElementById("uploadForm"),
  uploadZone: document.getElementById("uploadZone"),
  imageInput: document.getElementById("imageInput"),
  uploadPlaceholder: document.getElementById("uploadPlaceholder"),
  imagePreviewList: document.getElementById("imagePreviewList"),
  imageError: document.getElementById("imageError"),
  workTitle: document.getElementById("workTitle"),
  modelName: document.getElementById("modelName"),
  workShape: document.getElementById("workShape"),
  workColor: document.getElementById("workColor"),
  colorPicker: document.getElementById("colorPicker"),
  workNote: document.getElementById("workNote"),
  titleCount: document.getElementById("titleCount"),
  noteCount: document.getElementById("noteCount"),
  themeButton: document.querySelector(".theme-button"),
  toastRegion: document.getElementById("toastRegion"),
  currentYear: document.getElementById("currentYear")
};

const state = {
  works: [],
  bookings: [],
  selectedImages: [],
  bookingImage: "",
  search: "",
  shape: "Tümü",
  activeWorkId: null
};

const hoursAgo = (hours) => Date.now() - hours * 60 * 60 * 1000;
const dateInputValue = (date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

const createDemoImage = ({ background, accent, hair, skin, shape, index }) => {
  const hairShapes = {
    Uzun: "M155 170C105 270 105 505 132 790C205 826 515 826 588 790C615 505 615 270 565 170Z",
    Orta: "M150 165C105 265 100 475 132 675C214 718 506 718 588 675C620 475 615 265 570 165Z",
    Bob: "M160 160C108 250 100 505 165 632C245 672 475 672 555 632C620 505 612 250 560 160Z",
    Kısa: "M174 164C122 225 130 350 178 424C220 458 500 458 542 424C590 350 598 225 546 164Z",
    Dalgalı: "M144 180C87 285 102 500 120 760C190 803 510 803 580 760C598 500 613 285 556 180Z"
  };
  const fronts = {
    Uzun: "M182 270C180 160 248 108 360 108C472 108 540 160 538 270C500 218 460 190 360 198C282 204 224 224 182 270Z",
    Orta: "M182 270C180 160 248 108 360 108C472 108 540 160 538 270C500 218 460 190 360 198C282 204 224 224 182 270Z",
    Bob: "M186 300C180 180 250 125 360 125C470 125 540 180 534 300C494 245 450 222 360 230C270 238 226 256 186 300Z",
    Kısa: "M192 300C184 187 250 135 360 135C470 135 536 187 528 300C493 247 448 225 360 232C272 240 227 252 192 300Z",
    Dalgalı: "M176 310C180 204 235 142 294 132C290 182 260 208 238 248C266 235 286 209 304 178C337 231 392 251 450 206C473 230 502 267 532 306C525 194 463 120 360 120C252 120 184 190 176 310Z"
  };
  const curls = shape === "Dalgalı" ? `<g fill="${hair}" opacity=".96"><circle cx="184" cy="228" r="46"/><circle cx="222" cy="182" r="53"/><circle cx="279" cy="153" r="55"/><circle cx="346" cy="144" r="58"/><circle cx="417" cy="150" r="57"/><circle cx="488" cy="180" r="54"/><circle cx="532" cy="229" r="48"/></g>` : "";
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="720" height="900" viewBox="0 0 720 900"><defs><linearGradient id="bg${index}" x1="0" y1="0" x2="1" y2="1"><stop stop-color="${background}"/><stop offset="1" stop-color="${accent}"/></linearGradient><linearGradient id="hair${index}" x1="0" y1="0" x2="1" y2="1"><stop stop-color="${hair}"/><stop offset=".52" stop-color="${hair}"/><stop offset="1" stop-color="#1f1815"/></linearGradient><linearGradient id="skin${index}" x1="0" y1="0" x2="1" y2="1"><stop stop-color="${skin}"/><stop offset="1" stop-color="#ad6e55"/></linearGradient></defs><rect width="720" height="900" fill="url(#bg${index})"/><circle cx="92" cy="135" r="150" fill="#fff" opacity=".13"/><circle cx="654" cy="680" r="210" fill="#fff" opacity=".08"/><path d="M0 690C190 590 260 765 450 676C540 629 622 625 720 671V900H0Z" fill="#fff" opacity=".1"/><path d="M155 900C166 742 233 662 360 662C487 662 554 742 565 900Z" fill="${skin}"/><path d="${hairShapes[shape] || hairShapes.Orta}" fill="url(#hair${index})"/>${curls}<rect x="302" y="520" width="116" height="193" rx="55" fill="${skin}"/><ellipse cx="360" cy="365" rx="143" ry="190" fill="url(#skin${index})"/><ellipse cx="228" cy="370" rx="25" ry="38" fill="${skin}"/><ellipse cx="492" cy="370" rx="25" ry="38" fill="${skin}"/><path d="${fronts[shape] || fronts.Orta}" fill="url(#hair${index})"/><g fill="none" stroke="#fff" stroke-linecap="round" opacity=".16"><path d="M227 192C188 327 191 519 208 680" stroke-width="8"/><path d="M491 193C531 330 528 520 511 681" stroke-width="8"/><path d="M283 165C259 239 252 316 253 397" stroke-width="5"/><path d="M436 164C462 241 468 319 466 399" stroke-width="5"/></g><g fill="#332522" opacity=".72"><ellipse cx="304" cy="367" rx="7" ry="9"/><ellipse cx="416" cy="367" rx="7" ry="9"/></g><path d="M326 442C348 461 373 462 396 441" fill="none" stroke="#8c4f43" stroke-width="5" stroke-linecap="round"/></svg>`;
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
};

const seedWorks = [
  { id: "work-copper", title: "Sıcak bakır layered kesim", model: "Defne", shape: "Dalgalı", color: "Bakır", colorHex: "#a95131", note: "Kestane diplerden bakır uçlara yumuşak geçiş. Dalgalı doku ve taşınabilir boyut.", createdAt: hoursAgo(2), imageRatio: "tall", isOwner: false, image: createDemoImage({ background: "#d99b75", accent: "#9f5437", hair: "#6f3024", skin: "#e1aa8b", shape: "Dalgalı", index: 1 }) },
  { id: "work-blonde", title: "Soft blonde curtain cut", model: "Maya", shape: "Orta", color: "Bal", colorHex: "#d6aa62", note: "Doğal bal tonlarında perde kesim. Yüzü çerçeveleyen orta boy model.", createdAt: hoursAgo(5), imageRatio: "square", isOwner: false, image: createDemoImage({ background: "#b9c4a4", accent: "#87946d", hair: "#c49043", skin: "#edb89a", shape: "Orta", index: 2 }) },
  { id: "work-bob", title: "Kestane bob makas kesim", model: "İpek", shape: "Bob", color: "Kestane", colorHex: "#75452f", note: "Çene hizasında temiz bob. Parlak kestane ton ve hafif ışık yansıması.", createdAt: hoursAgo(9), imageRatio: "tall", isOwner: false, image: createDemoImage({ background: "#bdad91", accent: "#7a6b56", hair: "#5b3022", skin: "#c98968", shape: "Bob", index: 3 }) },
  { id: "work-black", title: "Siyah pixie dokü", model: "Sena", shape: "Kısa", color: "Siyah", colorHex: "#292522", note: "Günlük kullanım için kolay bakım. Çok kısa üst, yumuşak geçişli pixie.", createdAt: hoursAgo(14), imageRatio: "wide", isOwner: false, image: createDemoImage({ background: "#8d9690", accent: "#48534e", hair: "#211f1e", skin: "#d99c7e", shape: "Kısa", index: 4 }) },
  { id: "work-red", title: "Kızıl renk yenileme", model: "Lara", shape: "Bob", color: "Kızıl", colorHex: "#963b2e", note: "Koyu kestane üzerine kızıl renk yenileme. Parlak ve bakımı kolay.", createdAt: hoursAgo(20), imageRatio: "square", isOwner: false, image: createDemoImage({ background: "#d08a70", accent: "#944c3b", hair: "#762c27", skin: "#edb699", shape: "Bob", index: 5 }) },
  { id: "work-long", title: "Düz kesim long hair", model: "Aylin", shape: "Uzun", color: "Siyah", colorHex: "#2c2927", note: "Belinde dikey kesim, uçlarda hafif makas. Parlak siyah ve sade görünüm.", createdAt: hoursAgo(28), imageRatio: "tall", isOwner: false, image: createDemoImage({ background: "#b6aa9a", accent: "#69645d", hair: "#272321", skin: "#bf8366", shape: "Uzun", index: 6 }) }
];

const databasePromise = new Promise((resolve) => {
  if (!("indexedDB" in window)) {
    resolve(null);
    return;
  }
  const request = indexedDB.open(DB_NAME, DB_VERSION);
  request.onupgradeneeded = () => {
    if (!request.result.objectStoreNames.contains(STORE_NAME)) request.result.createObjectStore(STORE_NAME, { keyPath: "id" });
  };
  request.onsuccess = () => resolve(request.result);
  request.onerror = () => resolve(null);
});

const getStoredWorks = async () => {
  const database = await databasePromise;
  if (!database) {
    try { return JSON.parse(localStorage.getItem(`${DB_NAME}-fallback`) || "[]"); } catch { return []; }
  }
  return new Promise((resolve) => {
    const transaction = database.transaction(STORE_NAME, "readonly");
    const request = transaction.objectStore(STORE_NAME).getAll();
    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => resolve([]);
  });
};

const storeWork = async (work) => {
  const database = await databasePromise;
  if (!database) {
    const stored = await getStoredWorks();
    try { localStorage.setItem(`${DB_NAME}-fallback`, JSON.stringify([...stored.filter((item) => item.id !== work.id), work])); } catch { showToast("Çalışma eklendi, ancak kalıcı kaydedilemedi.", "warning"); }
    return;
  }
  await new Promise((resolve) => {
    const transaction = database.transaction(STORE_NAME, "readwrite");
    transaction.objectStore(STORE_NAME).put(work);
    transaction.oncomplete = resolve;
    transaction.onerror = resolve;
  });
};

const removeStoredWork = async (id) => {
  const database = await databasePromise;
  if (!database) {
    const stored = await getStoredWorks();
    try { localStorage.setItem(`${DB_NAME}-fallback`, JSON.stringify(stored.filter((work) => work.id !== id))); } catch { return; }
    return;
  }
  await new Promise((resolve) => {
    const transaction = database.transaction(STORE_NAME, "readwrite");
    transaction.objectStore(STORE_NAME).delete(id);
    transaction.oncomplete = resolve;
    transaction.onerror = resolve;
  });
};

const escapeHtml = (value = "") => String(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;");
const normalize = (value) => String(value).toLocaleLowerCase("tr-TR").trim();
const safeColor = (value = "#8b5e3c") => /^#[0-9a-f]{6}$/i.test(value) ? value : "#8b5e3c";
const safeImage = (value = "") => /^data:image\/(?:jpeg|png|webp|svg\+xml)(?:;[^,]*)?,/i.test(value) ? value : seedWorks[0].image;
const getInitial = (value) => String(value || "M").trim().charAt(0).toLocaleUpperCase("tr-TR");
const formatNumber = (value) => new Intl.NumberFormat("tr-TR").format(value);
const sortByNewest = (left, right) => right.createdAt - left.createdAt;
const makeId = (prefix) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

const formatWorkDate = (date) => new Intl.DateTimeFormat("tr-TR", { day: "numeric", month: "short" }).format(date);
const formatBookingDate = (value) => {
  const date = new Date(`${value}T12:00:00`);
  return new Intl.DateTimeFormat("tr-TR", { day: "2-digit", month: "short" }).format(date);
};

const getFilteredWorks = () => {
  const search = normalize(state.search);
  return state.works.filter((work) => {
    if (state.shape !== "Tümü" && work.shape !== state.shape) return false;
    if (!search) return true;
    return normalize([work.title, work.model, work.shape, work.color, work.note].filter(Boolean).join(" ")).includes(search);
  }).sort(sortByNewest);
};

const workCardTemplate = (work) => {
  const color = safeColor(work.colorHex);
  const title = escapeHtml(work.title);
  const model = escapeHtml(work.model || "Model bilgisi yok");
  return `<article class="portfolio-card" data-work-id="${escapeHtml(work.id)}" tabindex="0" role="button" aria-label="${title} çalışmasını aç"><div class="portfolio-card-image" style="--tag-color:${color}"><img src="${escapeHtml(safeImage(work.image))}" alt="${title} fotoğrafı" loading="lazy" /><div class="portfolio-card-tags"><span class="portfolio-tag">${escapeHtml(work.shape)}</span><span class="portfolio-tag"><i></i>${escapeHtml(work.color)}</span></div>${work.isOwner ? '<span class="owner-ribbon">Yeni çalışma</span>' : ""}</div><div class="portfolio-card-body"><div class="portfolio-card-title"><h3>${title}</h3><span>${formatWorkDate(work.createdAt)}</span></div><div class="portfolio-card-meta"><span><span class="author-avatar" style="--post-color:${color}">${getInitial(work.model || "M")}</span>${model}</span><span>${escapeHtml(work.color)}</span></div></div></article>`;
};

const renderPortfolio = () => {
  const works = getFilteredWorks();
  elements.portfolioGrid.innerHTML = works.map(workCardTemplate).join("");
  elements.portfolioCount.textContent = formatNumber(works.length);
  elements.portfolioEmpty.hidden = works.length > 0;
  elements.portfolioGrid.hidden = works.length === 0;
};

const renderAppointments = () => {
  elements.appointmentList.innerHTML = state.bookings.map((booking) => {
    const statusClass = booking.status === "Onaylandı" ? "confirmed" : booking.status === "Tamamlandı" ? "done" : booking.status === "İptal" ? "cancelled" : "";
    const action = booking.status === "Bekliyor" ? `<button class="mini-action" type="button" data-action="approve-booking" data-booking-id="${escapeHtml(booking.id)}">Onayla</button><button class="mini-action" type="button" data-action="cancel-booking" data-booking-id="${escapeHtml(booking.id)}">İptal</button>` : booking.status === "Onaylandı" ? `<button class="mini-action" type="button" data-action="complete-booking" data-booking-id="${escapeHtml(booking.id)}">Tamamla</button><button class="mini-action" type="button" data-action="cancel-booking" data-booking-id="${escapeHtml(booking.id)}">İptal</button>` : "";
    const reference = booking.image ? `<img class="appointment-thumb" src="${escapeHtml(safeImage(booking.image))}" alt="Müşteri referansı" />` : "";
    const preference = [booking.hairColor, booking.brand].filter(Boolean).join(" · ") || "Tercih belirtilmedi";
    return `<article class="appointment-card" style="--booking-color:${safeColor(booking.color)}"><span class="booking-avatar">${getInitial(booking.name)}</span><div class="appointment-main"><div><strong>${escapeHtml(booking.name)}</strong><span>${escapeHtml(booking.phone)}</span></div>${reference}</div><div class="appointment-detail"><strong>${escapeHtml(booking.service)}</strong><span>${formatBookingDate(booking.date)} · ${escapeHtml(booking.time)}</span></div><div class="appointment-detail appointment-detail-hide-mobile"><strong>${escapeHtml(preference)}</strong><span>${escapeHtml(booking.note || "Not yok")} · ${escapeHtml(booking.status)}</span></div><span class="appointment-status ${statusClass}">${escapeHtml(booking.status)}</span><div class="appointment-actions">${action}</div></article>`;
  }).join("");
  elements.appointmentEmpty.hidden = state.bookings.length > 0;
};

const setTheme = (theme) => {
  const nextTheme = theme === "dark" ? "dark" : "light";
  elements.root.dataset.theme = nextTheme;
  localStorage.setItem(THEME_KEY, nextTheme);
  elements.themeButton.setAttribute("aria-label", nextTheme === "dark" ? "Açık temayı aç" : "Koyu temayı aç");
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = nextTheme === "dark" ? "#101214" : "#e8eaec";
};

const initializeTheme = () => {
  const stored = localStorage.getItem(THEME_KEY);
  const preferred = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  setTheme(stored || preferred);
};

const showToast = (message, type = "success") => {
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.setAttribute("role", "status");
  toast.innerHTML = `<span class="toast-icon"${type === "warning" ? ' style="background:var(--salon-accent-soft);color:var(--salon-accent-dark)"' : ""}>${type === "warning" ? "!" : "✓"}</span><span>${escapeHtml(message)}</span>`;
  elements.toastRegion.append(toast);
  window.setTimeout(() => { toast.classList.add("out"); window.setTimeout(() => toast.remove(), 220); }, 3200);
};

const updateBodyLock = () => elements.body.classList.toggle("dialog-open", elements.uploadDialog.open || elements.detailDialog.open);

const openUpload = () => {
  if (!elements.uploadDialog.open) {
    elements.uploadDialog.showModal();
    updateBodyLock();
    window.setTimeout(() => elements.uploadZone.focus(), 50);
  }
};

const closeUpload = () => { if (elements.uploadDialog.open) elements.uploadDialog.close(); };

const openBooking = () => {
  if (!elements.bookingSuccess.hidden) resetBooking();
  document.getElementById("randevu").scrollIntoView({ behavior: "smooth" });
  window.setTimeout(() => elements.bookingName.focus(), 350);
};

const resetBooking = () => {
  elements.bookingForm.reset();
  clearBookingImage();
  elements.bookingDate.min = dateInputValue(new Date());
  elements.bookingDate.value = dateInputValue(new Date());
  elements.bookingSuccess.hidden = true;
  elements.bookingForm.hidden = false;
};

const openDetail = (id) => {
  const work = state.works.find((item) => item.id === id);
  if (!work) return;
  state.activeWorkId = id;
  const color = safeColor(work.colorHex);
  const title = escapeHtml(work.title);
  const note = escapeHtml(work.note || "Bu çalışma için ayrıca not eklenmemiş.");
  const model = escapeHtml(work.model || "Model bilgisi yok");
  const deleteButton = work.isOwner ? `<button class="button button-ghost detail-delete" type="button" data-action="delete-work"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3M7 7l1 14h8l1-14M10 11v6M14 11v6"></path></svg>Çalışmayı sil</button>` : `<p class="detail-owner-note"><span>✦</span><span>Salon X portföyünde yer alan bir çalışma.</span></p>`;
  elements.detailPanel.innerHTML = `<div class="detail-image-wrap" style="--tag-color:${color}"><img src="${escapeHtml(safeImage(work.image))}" alt="${title} fotoğrafı" /><button class="detail-close" type="button" data-action="close-detail" aria-label="Pencereyi kapat"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"></path></svg></button></div><div class="detail-content"><div class="detail-author" style="--booking-color:${color}"><span class="detail-author-avatar">${getInitial(work.model || "M")}</span><div><p>${model}</p><small>Salon X · ${formatWorkDate(work.createdAt)}</small></div></div><h2 id="detailTitle">${title}</h2><p class="detail-description">${note}</p><div class="detail-tags"><span class="detail-tag"><i></i>${escapeHtml(work.color)}</span><span class="detail-tag">${escapeHtml(work.shape)} saç</span></div><div class="detail-divider"></div><div class="detail-actions">${deleteButton}</div></div>`;
  if (!elements.detailDialog.open) elements.detailDialog.showModal();
  updateBodyLock();
};

const closeDetail = () => { if (elements.detailDialog.open) elements.detailDialog.close(); state.activeWorkId = null; };

const deleteActiveWork = async () => {
  const work = state.works.find((item) => item.id === state.activeWorkId);
  if (!work || !work.isOwner) return;
  if (!window.confirm("Bu çalışmayı silmek istediğine emin misin?")) return;
  state.works = state.works.filter((item) => item.id !== work.id);
  await removeStoredWork(work.id);
  closeDetail();
  renderPortfolio();
  showToast("Çalışma portföyden kaldırıldı.");
};

const readFileAsDataUrl = (file) => new Promise((resolve, reject) => {
  const reader = new FileReader();
  reader.onload = () => resolve(reader.result);
  reader.onerror = () => reject(new Error("Dosya okunamadı."));
  reader.readAsDataURL(file);
});

const compressImage = (file, options = {}) => new Promise((resolve, reject) => {
  const maxEdge = options.maxEdge || 1400;
  const maxBytes = options.maxBytes || 2700000;
  const startQuality = options.startQuality || 0.84;
  readFileAsDataUrl(file).then((dataUrl) => {
    const image = new Image();
    image.onload = () => {
      const scale = Math.min(1, maxEdge / Math.max(image.naturalWidth, image.naturalHeight));
      const width = Math.max(1, Math.round(image.naturalWidth * scale));
      const height = Math.max(1, Math.round(image.naturalHeight * scale));
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      const context = canvas.getContext("2d");
      context.fillStyle = "#f5f2ec";
      context.fillRect(0, 0, width, height);
      context.drawImage(image, 0, 0, width, height);
      let quality = startQuality;
      let output = canvas.toDataURL("image/jpeg", quality);
      while (output.length > maxBytes && quality > 0.42) {
        quality -= 0.08;
        output = canvas.toDataURL("image/jpeg", quality);
      }
      const ratio = width / height;
      resolve({ output, imageRatio: ratio > 1.18 ? "wide" : ratio < 0.84 ? "tall" : "square" });
    };
    image.onerror = () => reject(new Error("Görsel açılamadı."));
    image.src = dataUrl;
  }).catch(reject);
});

const renderImagePreviews = () => {
  elements.imagePreviewList.hidden = state.selectedImages.length === 0;
  elements.uploadPlaceholder.hidden = state.selectedImages.length > 0;
  elements.imagePreviewList.innerHTML = state.selectedImages.map((image, index) => `<div class="preview-thumb"><img src="${escapeHtml(image.image)}" alt="Yüklenen fotoğraf ${index + 1}" /><span>${index + 1}. fotoğraf</span></div>`).join("");
};

const handleImageFiles = async (files) => {
  elements.imageError.classList.remove("visible");
  elements.imageError.textContent = "";
  const fileList = Array.from(files || []);
  if (!fileList.length) return;
  if (state.selectedImages.length + fileList.length > 8) {
    elements.imageError.textContent = "Tek seferde en fazla 8 fotoğraf ekleyebilirsin.";
    elements.imageError.classList.add("visible");
    return;
  }
  const allowedTypes = ["image/jpeg", "image/png", "image/webp"];
  const invalid = fileList.find((file) => !allowedTypes.includes(file.type) || file.size > 8 * 1024 * 1024);
  if (invalid) {
    elements.imageError.textContent = "Fotoğraflar JPG, PNG veya WEBP formatında ve en fazla 8 MB olmalı.";
    elements.imageError.classList.add("visible");
    return;
  }
  elements.uploadPlaceholder.querySelector("strong").textContent = "Fotoğraflar hazırlanıyor...";
  try {
    for (const file of fileList) {
      const result = await compressImage(file);
      state.selectedImages.push({ image: result.output, imageRatio: result.imageRatio, name: file.name });
    }
    renderImagePreviews();
  } catch (error) {
    elements.imageError.textContent = error.message || "Fotoğraf yüklenemedi.";
    elements.imageError.classList.add("visible");
  } finally {
    elements.uploadPlaceholder.querySelector("strong").textContent = "Fotoğrafları buraya sürükle";
  }
};

const clearBookingImage = () => {
  state.bookingImage = "";
  elements.bookingImageInput.value = "";
  elements.bookingReferenceImage.removeAttribute("src");
  elements.bookingReferencePreview.hidden = true;
  elements.bookingReferencePlaceholder.hidden = false;
  elements.bookingImageError.classList.remove("visible");
  elements.bookingImageError.textContent = "";
};

const openBookingImage = () => elements.bookingImageInput.click();

const handleBookingImage = async (file) => {
  elements.bookingImageError.classList.remove("visible");
  elements.bookingImageError.textContent = "";
  if (!file) return;
  const allowedTypes = ["image/jpeg", "image/png", "image/webp"];
  if (!allowedTypes.includes(file.type) || file.size > 8 * 1024 * 1024) {
    elements.bookingImageError.textContent = "Referans fotoğrafı JPG, PNG veya WEBP formatında ve en fazla 8 MB olmalı.";
    elements.bookingImageError.classList.add("visible");
    return;
  }
  elements.bookingReferencePlaceholder.querySelector("strong").textContent = "Fotoğraf hazırlanıyor...";
  try {
    const result = await compressImage(file, { maxEdge: 1000, maxBytes: 1500000, startQuality: 0.78 });
    state.bookingImage = result.output;
    elements.bookingReferenceImage.src = state.bookingImage;
    elements.bookingReferencePreview.hidden = false;
    elements.bookingReferencePlaceholder.hidden = true;
  } catch (error) {
    elements.bookingImageError.textContent = error.message || "Referans fotoğrafı yüklenemedi.";
    elements.bookingImageError.classList.add("visible");
  } finally {
    elements.bookingReferencePlaceholder.querySelector("strong").textContent = "İstediğin saç şeklinin fotoğrafını ekle";
  }
};

const validateUpload = () => {
  let valid = state.selectedImages.length > 0;
  if (!valid) {
    elements.imageError.textContent = "En az bir model fotoğrafı eklemelisin.";
    elements.imageError.classList.add("visible");
  }
  const fields = [[elements.workTitle, elements.workTitle.value.trim()], [elements.workShape, elements.workShape.value], [elements.workColor, elements.workColor.value.trim()]];
  fields.forEach(([field, value]) => field.classList.toggle("invalid", !value));
  return valid && fields.every(([, value]) => value);
};

const resetUpload = () => {
  elements.uploadForm.reset();
  state.selectedImages = [];
  elements.imagePreviewList.innerHTML = "";
  elements.imagePreviewList.hidden = true;
  elements.uploadPlaceholder.hidden = false;
  elements.imageError.classList.remove("visible");
  elements.titleCount.textContent = "0";
  elements.noteCount.textContent = "0";
};

const submitWorks = async (event) => {
  event.preventDefault();
  if (!validateUpload()) return;
  const title = elements.workTitle.value.trim();
  const model = elements.modelName.value.trim();
  const shape = elements.workShape.value;
  const color = elements.workColor.value.trim();
  const note = elements.workNote.value.trim();
  const colorHex = safeColor(elements.colorPicker.value);
  const created = state.selectedImages.map((image, index) => ({ id: makeId("work"), title, model, shape, color, colorHex, note, image: image.image, imageRatio: image.imageRatio, createdAt: Date.now() - index, isOwner: true }));
  state.works = [...created, ...state.works];
  await Promise.all(created.map(storeWork));
  state.search = "";
  state.shape = "Tümü";
  elements.portfolioSearch.value = "";
  elements.portfolioShape.value = "Tümü";
  renderPortfolio();
  closeUpload();
  resetUpload();
  showToast(`${created.length} fotoğraf portföye eklendi.`);
  window.setTimeout(() => elements.portfolioGrid.firstElementChild?.scrollIntoView({ behavior: "smooth", block: "center" }), 150);
};

const saveBookings = () => {
  try { localStorage.setItem(BOOKINGS_KEY, JSON.stringify(state.bookings)); } catch { showToast("Randevu kaydedilemedi.", "warning"); }
};

const getSeedBookings = () => {
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const dayAfter = new Date();
  dayAfter.setDate(dayAfter.getDate() + 2);
  return [
    { id: "booking-seed-1", name: "Ayşe Yılmaz", phone: "0532 444 18 22", service: "Kadın kesim & fön", date: dateInputValue(tomorrow), time: "11:30", note: "Omuz altı boy.", hairColor: "Bakır", brand: "Wella", status: "Bekliyor", color: "#c88162", createdAt: hoursAgo(1) },
    { id: "booking-seed-2", name: "Deniz Kaya", phone: "0541 220 90 11", service: "Saç boyama", date: dateInputValue(dayAfter), time: "16:00", note: "Kestane tonu.", hairColor: "Kestane", brand: "L’Oréal Paris", status: "Onaylandı", color: "#66816b", createdAt: hoursAgo(4) }
  ];
};

const getStoredBookings = () => {
  try {
    const stored = localStorage.getItem(BOOKINGS_KEY);
    return stored ? JSON.parse(stored) : getSeedBookings();
  } catch { return getSeedBookings(); }
};

const submitBooking = (event) => {
  event.preventDefault();
  const fields = [[elements.bookingName, elements.bookingName.value.trim()], [elements.bookingPhone, elements.bookingPhone.value.trim()], [elements.bookingService, elements.bookingService.value], [elements.bookingDate, elements.bookingDate.value], [elements.bookingTime, elements.bookingTime.value]];
  fields.forEach(([field, value]) => field.classList.toggle("invalid", !value));
  if (fields.some(([, value]) => !value)) return;
  const booking = { id: makeId("booking"), name: elements.bookingName.value.trim(), phone: elements.bookingPhone.value.trim(), service: elements.bookingService.value, hairColor: elements.bookingColor.value.trim(), brand: elements.bookingBrand.value.trim(), date: elements.bookingDate.value, time: elements.bookingTime.value, note: elements.bookingNote.value.trim(), image: state.bookingImage, status: "Bekliyor", color: "#b96545", createdAt: Date.now() };
  state.bookings.unshift(booking);
  saveBookings();
  renderAppointments();
  const preferenceText = [booking.hairColor, booking.brand].filter(Boolean).join(" · ");
  elements.bookingSuccessText.textContent = `${booking.service} için ${formatBookingDate(booking.date)} ${booking.time} randevu talebin alındı. Onay sonrası seni arayacağız.${preferenceText ? ` ${preferenceText} tercihin de eklendi.` : ""}${booking.image ? " Referans fotoğrafın da eklendi." : ""}`;
  elements.bookingForm.hidden = true;
  elements.bookingSuccess.hidden = false;
  showToast("Randevu talebin alındı.");
};

const updateBooking = (id, status) => {
  const booking = state.bookings.find((item) => item.id === id);
  if (!booking) return;
  booking.status = status;
  saveBookings();
  renderAppointments();
  showToast(`Randevu durumu "${status}" olarak güncellendi.`);
};

const handleDocumentClick = (event) => {
  const actionElement = event.target.closest("[data-action]");
  if (actionElement) {
    const action = actionElement.dataset.action;
    if (action === "open-upload") openUpload();
    if (action === "close-upload") closeUpload();
    if (action === "close-detail") closeDetail();
    if (action === "open-booking") openBooking();
    if (action === "new-booking") resetBooking();
    if (action === "change-booking-image") openBookingImage();
    if (action === "remove-booking-image") clearBookingImage();
    if (action === "toggle-theme") setTheme(elements.root.dataset.theme === "dark" ? "light" : "dark");
    if (action === "delete-work") deleteActiveWork();
    if (action === "approve-booking") updateBooking(actionElement.dataset.bookingId, "Onaylandı");
    if (action === "cancel-booking") updateBooking(actionElement.dataset.bookingId, "İptal");
    if (action === "complete-booking") updateBooking(actionElement.dataset.bookingId, "Tamamlandı");
  }
  const card = event.target.closest(".portfolio-card");
  if (card && !event.target.closest("[data-action]")) openDetail(card.dataset.workId);
};

const handleCardKeydown = (event) => {
  const card = event.target.closest(".portfolio-card");
  if (card && (event.key === "Enter" || event.key === " ")) {
    event.preventDefault();
    openDetail(card.dataset.workId);
  }
};

const handleBackdropClick = (dialog, close) => {
  dialog.addEventListener("click", (event) => { if (event.target === dialog) close(); });
  dialog.addEventListener("close", updateBodyLock);
};

const bindEvents = () => {
  document.addEventListener("click", handleDocumentClick);
  elements.portfolioGrid.addEventListener("keydown", handleCardKeydown);
  elements.portfolioSearch.addEventListener("input", (event) => { state.search = event.target.value; renderPortfolio(); });
  elements.portfolioShape.addEventListener("change", (event) => { state.shape = event.target.value; renderPortfolio(); });
  elements.uploadForm.addEventListener("submit", submitWorks);
  elements.imageInput.addEventListener("change", () => handleImageFiles(elements.imageInput.files));
  elements.uploadZone.addEventListener("click", () => elements.imageInput.click());
  elements.uploadZone.addEventListener("keydown", (event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); elements.imageInput.click(); } });
  ["dragenter", "dragover"].forEach((eventName) => elements.uploadZone.addEventListener(eventName, (event) => { event.preventDefault(); elements.uploadZone.classList.add("dragging"); }));
  ["dragleave", "drop"].forEach((eventName) => elements.uploadZone.addEventListener(eventName, (event) => { event.preventDefault(); elements.uploadZone.classList.remove("dragging"); }));
  elements.uploadZone.addEventListener("drop", (event) => handleImageFiles(event.dataTransfer.files));
  elements.workTitle.addEventListener("input", () => { elements.titleCount.textContent = elements.workTitle.value.length; });
  elements.workNote.addEventListener("input", () => { elements.noteCount.textContent = elements.workNote.value.length; });
  elements.bookingForm.addEventListener("submit", submitBooking);
  elements.bookingImageInput.addEventListener("change", () => handleBookingImage(elements.bookingImageInput.files[0]));
  elements.bookingReferenceZone.addEventListener("click", (event) => { if (!event.target.closest("[data-action]")) openBookingImage(); });
  elements.bookingReferenceZone.addEventListener("keydown", (event) => { if ((event.key === "Enter" || event.key === " ") && !event.target.closest("[data-action]")) { event.preventDefault(); openBookingImage(); } });
  ["dragenter", "dragover"].forEach((eventName) => elements.bookingReferenceZone.addEventListener(eventName, (event) => { event.preventDefault(); elements.bookingReferenceZone.classList.add("dragging"); }));
  ["dragleave", "drop"].forEach((eventName) => elements.bookingReferenceZone.addEventListener(eventName, (event) => { event.preventDefault(); elements.bookingReferenceZone.classList.remove("dragging"); }));
  elements.bookingReferenceZone.addEventListener("drop", (event) => handleBookingImage(event.dataTransfer.files[0]));
  window.addEventListener("scroll", () => elements.header.classList.toggle("scrolled", window.scrollY > 12), { passive: true });
  handleBackdropClick(elements.uploadDialog, closeUpload);
  handleBackdropClick(elements.detailDialog, closeDetail);
};

const loadWorks = async () => {
  const stored = await getStoredWorks();
  const merged = new Map(seedWorks.map((work) => [work.id, { ...work }]));
  stored.forEach((work) => { if (work && typeof work.id === "string") merged.set(work.id, work); });
  state.works = [...merged.values()].sort(sortByNewest);
  renderPortfolio();
};

const initialize = async () => {
  elements.currentYear.textContent = String(new Date().getFullYear());
  elements.bookingDate.min = dateInputValue(new Date());
  elements.bookingDate.value = dateInputValue(new Date());
  initializeTheme();
  bindEvents();
  state.works = seedWorks.map((work) => ({ ...work }));
  state.bookings = getStoredBookings();
  renderPortfolio();
  renderAppointments();
  await loadWorks();
};

initialize();
